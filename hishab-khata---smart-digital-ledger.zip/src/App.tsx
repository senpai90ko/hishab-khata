/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  Smartphone,
  Maximize2,
  RotateCcw,
  Info,
  ShieldCheck,
  Camera,
  Users,
  FileText,
  ExternalLink,
  Check,
  Copy,
  Sparkles,
  Fingerprint,
  ZoomIn,
  ZoomOut,
  Palette,
  Download,
  CheckCircle2,
  Grid,
  X,
  QrCode,
  Share2,
  ArrowRight
} from 'lucide-react';

import dogLogo from './assets/images/dog_logo.png';
import logoEmerald from './assets/images/hishab_logo_emerald_1794342705753.jpg';
import logoMonogram from './assets/images/hishab_logo_monogram_1794342705787.jpg';
import logoRedKhata from './assets/images/hishab_logo_redkhata_1794342707191.jpg';
import logoSecurity from './assets/images/hishab_logo_security_1794342707601.jpg';

interface LogoOption {
  id: string;
  titleBn: string;
  titleEn: string;
  themeBn: string;
  themeEn: string;
  descriptionBn: string;
  src: string;
  accentColor: string;
  tag: string;
}

const LOGO_OPTIONS: LogoOption[] = [
  {
    id: 'doge',
    titleBn: 'স্মাইলিং ডগ (অফিসিয়াল আইকন)',
    titleEn: 'Smiling Doge Mascot',
    themeBn: 'আপনার নির্বাচিত অফিসিয়াল অ্যাপ আইকন',
    themeEn: 'User-selected Smiling Dog Mascot Icon',
    descriptionBn: 'আপনার দেওয়া হাস্যোজ্জ্বল ডগ ম্যাসকট—অ্যাপের ইনস্টলড হোমস্ক্রিন আইকন ও ব্রাউজার আইকন হিসেবে সক্রিয় রয়েছে।',
    src: dogLogo,
    accentColor: '#f59e0b',
    tag: 'অফিসিয়াল আইকন (Active)'
  },
  {
    id: 'emerald',
    titleBn: 'পান্না ও সোনালী লেজার',
    titleEn: 'Emerald & Gold 3D Book',
    themeBn: 'আধুনিক প্রিমিয়াম ৩D বিজনেস স্টাইল',
    themeEn: 'Modern Premium 3D Ledger with Security Lock',
    descriptionBn: 'পান্না সবুজ চামড়ার বাঁধাই করা ডিজিটাল লেজার বই, সূক্ষ্ম সোনালী বর্ডার ও ঝকঝকে প্যাডলক—বিশ্বাসযোগ্যতা ও নিরাপত্তার প্রতীক।',
    src: logoEmerald,
    accentColor: '#10b981',
    tag: 'ডিজিটাল লেজার'
  },
  {
    id: 'monogram',
    titleBn: "বাংলা 'হ' মনোগ্রাম ফিনটেক",
    titleEn: "Bengali 'হ' Fintech Monogram",
    themeBn: 'মিনিমালিস্ট ও ফিনটেক ব্র্যান্ডিং',
    themeEn: 'Sculpted Golden Ribbon & Credit Ledger',
    descriptionBn: "বাংলা 'হিসাব' শব্দের আদ্যক্ষর 'হ'-কে আধুনিক গোল্ডেন ফিতা আকারে রূপ দিয়ে আর্থিক হিসাবের প্লাস-মাইনাস ও ডিজিটাল ব্যালেন্সের নিখুঁত রূপ।",
    src: logoMonogram,
    accentColor: '#f59e0b',
    tag: 'মিনিমালিস্ট'
  },
  {
    id: 'redkhata',
    titleBn: 'ঐতিহ্যবাহী লাল খাতা',
    titleEn: 'Classic Crimson Red Khata',
    themeBn: 'বাঙালির ঐতিহাসিক হালখাতা ও লাল খাতা ঐতিহ্য',
    themeEn: 'Embossed Crimson Leather with Gold Foil',
    descriptionBn: 'দোকান ও ব্যবসার শতাব্দী প্রাচীন লাল মলাটের হিসাব বহি (খাতা), সাথে এমবসড সোনালী নকশা, বুকমার্ক ফিতা ও ফাউন্টেন পেন।',
    src: logoRedKhata,
    accentColor: '#ef4444',
    tag: 'ঐতিহ্যবাহী'
  },
  {
    id: 'security',
    titleBn: 'স্মার্ট বায়োমেট্রিক সিকিউরিটি',
    titleEn: 'Biometric Smart Ledger',
    themeBn: 'উচ্চ প্রযুক্তিসম্পন্ন বায়োমেট্রিক ও সাইবার সুরক্ষা',
    themeEn: 'Glowing Cyan Fingerprint & Royal Blue Gold',
    descriptionBn: 'রয়েল ব্লু ব্যাকগ্রাউন্ডে উজ্জ্বল নিয়ন ফিঙ্গারপ্রিন্ট সেন্সর ও স্বর্ণমুদ্রার স্তূপ—আপনার হিসাবের শতভাগ গোপনীয়তার নিশ্চয়তা।',
    src: logoSecurity,
    accentColor: '#06b6d4',
    tag: 'হাই-টেক সিকিউরিটি'
  }
];

type DevicePreset = 'iphone' | 'pixel' | 'responsive';

export default function App() {
  const [device, setDevice] = useState<DevicePreset>('iphone');
  const [scale, setScale] = useState<number>(0.88);
  const [currentTime, setCurrentTime] = useState<string>('');
  const [showGuide, setShowGuide] = useState<boolean>(false);
  const [showLogoModal, setShowLogoModal] = useState<boolean>(false);
  const [showPhoneSetup, setShowPhoneSetup] = useState<boolean>(false);
  const [phoneOsTab, setPhoneOsTab] = useState<'android' | 'iphone' | 'apk'>('android');
  const [logoTab, setLogoTab] = useState<'gallery' | 'homescreen'>('gallery');
  const [activeLogo, setActiveLogo] = useState<LogoOption>(LOGO_OPTIONS[0]); // Dog logo by default!
  const [copiedPin, setCopiedPin] = useState<boolean>(false);
  const [copiedUrl, setCopiedUrl] = useState<boolean>(false);
  const [iframeKey, setIframeKey] = useState<number>(1);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const APP_URL = 'https://ais-pre-qyo3iy6snrs26plnotb7or-573224062685.europe-west2.run.app';

  // Live status bar time
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleRefresh = () => {
    setIframeKey((prev) => prev + 1);
  };

  const copyPin = () => {
    navigator.clipboard.writeText('1234');
    setCopiedPin(true);
    setTimeout(() => setCopiedPin(false), 2000);
  };

  const copyAppUrl = () => {
    navigator.clipboard.writeText(APP_URL);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const getDeviceDimensions = () => {
    switch (device) {
      case 'iphone':
        return { width: 393, height: 820, name: 'iPhone 16 Pro' };
      case 'pixel':
        return { width: 412, height: 840, name: 'Google Pixel 9' };
      case 'responsive':
        return { width: '100%', height: '100%', name: 'Full Responsive' };
    }
  };

  const dims = getDeviceDimensions();

  return (
    <div className="h-screen w-screen bg-slate-950 text-slate-100 flex flex-col font-sans overflow-hidden selection:bg-amber-500/30 selection:text-amber-200">
      {/* Top Header / Control Bar */}
      <header className="h-14 border-b border-slate-800 bg-slate-900/90 backdrop-blur-md px-3 sm:px-4 flex items-center justify-between z-30 shrink-0 gap-3">
        {/* App Title & Active Logo Badge */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowLogoModal(true)}
            className="group relative flex items-center justify-center transition-transform hover:scale-105 active:scale-95"
            title="অ্যাপ আইকন দেখতে বা পরিবর্তন করতে ক্লিক করুন"
          >
            <div className="w-10 h-10 rounded-xl overflow-hidden shadow-md border-2 border-amber-500/60 p-0.5 bg-slate-900 group-hover:border-amber-400 flex items-center justify-center">
              <img
                src={activeLogo.src}
                alt={activeLogo.titleBn}
                className="w-full h-full object-contain rounded-lg"
              />
            </div>
            <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-amber-500 rounded-full border-2 border-slate-900 flex items-center justify-center">
              <Check className="w-2 h-2 text-slate-950 stroke-[3]" />
            </span>
          </button>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-bold text-sm tracking-tight text-white flex items-center gap-1.5">
                Developed By Affan
              </h1>
              <span className="text-[10px] font-semibold bg-amber-500/15 text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded-full">
                Live App
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:block">
              স্মার্ট ডিজিটাল হিসাব খাতা ও বায়োমেট্রিক সিকিউরিটি
            </p>
          </div>
        </div>

        {/* Center Quick Hint (PIN & Logo Picker CTA) */}
        <div className="hidden lg:flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700/60 text-xs text-slate-300">
          <span className="flex items-center gap-1 text-emerald-400 font-medium">
            <Fingerprint className="w-3.5 h-3.5" />
            ফিঙ্গারপ্রিন্ট আনলক
          </span>
          <span className="text-slate-600">|</span>
          <span>পাসওয়ার্ড পিন:</span>
          <button
            onClick={copyPin}
            className="flex items-center gap-1 font-mono font-bold text-amber-300 hover:text-amber-200 bg-amber-950/40 px-1.5 py-0.5 rounded border border-amber-500/20"
            title="পিন কপি করতে ক্লিক করুন"
          >
            <span>1234</span>
            {copiedPin ? (
              <Check className="w-3 h-3 text-emerald-400" />
            ) : (
              <Copy className="w-3 h-3 text-slate-400" />
            )}
          </button>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* Direct Download Android APK Button */}
          <a
            href="/Developed_By_Affan.apk"
            download="Developed_By_Affan.apk"
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-md shadow-emerald-950/40 border border-emerald-400/40 transition-all hover:scale-102 active:scale-98 animate-pulse"
            title="Developed_By_Affan.apk (194 KB) ডাউনলোড করুন"
          >
            <Download className="w-3.5 h-3.5" />
            <span>ডাউনলোড APK</span>
            <span className="bg-emerald-950/60 text-emerald-300 text-[10px] px-1.5 py-0.2 rounded-full font-mono border border-emerald-500/30">
              194 KB
            </span>
          </a>

          {/* Direct Download HTML File Button */}
          <a
            href="/assets/aistudio/hishab_khata_wrong_password_photo_cc36a4cb.html"
            download="Developed_By_Affan_App.html"
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-all"
            title="অফলাইন HTML ফাইল ডাউনলোড"
          >
            <Download className="w-3.5 h-3.5" />
            <span>HTML ফাইল</span>
          </a>

          {/* Phone Setup CTA Button */}
          <button
            onClick={() => setShowPhoneSetup(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-950/40 border border-emerald-400/30 transition-all hover:scale-102 active:scale-98"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">ফোনে সেটআপ গাইড</span>
            <span className="sm:hidden">গাইড</span>
          </button>

          {/* Logo Showcase Trigger Button */}
          <button
            onClick={() => setShowLogoModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white shadow-md shadow-amber-950/40 border border-amber-400/30 transition-all hover:scale-102 active:scale-98"
          >
            <Palette className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">অ্যাপ আইকন</span>
            <span className="sm:hidden">আইকন</span>
            <span className="bg-white/20 text-[10px] px-1.5 py-0.2 rounded-full font-mono">
              Dog
            </span>
          </button>

          {/* Device Frame Switcher */}
          <div className="flex items-center bg-slate-900 border border-slate-800 rounded-lg p-0.5">
            <button
              onClick={() => { setDevice('iphone'); setScale(0.88); }}
              className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md transition-all ${
                device === 'iphone'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="iPhone View (393 x 820)"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">iPhone</span>
            </button>
            <button
              onClick={() => { setDevice('pixel'); setScale(0.88); }}
              className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md transition-all ${
                device === 'pixel'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Pixel View (412 x 840)"
            >
              <Smartphone className="w-3.5 h-3.5 rotate-1" />
              <span className="hidden sm:inline">Pixel</span>
            </button>
            <button
              onClick={() => { setDevice('responsive'); setScale(1); }}
              className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md transition-all ${
                device === 'responsive'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Full Window View"
            >
              <Maximize2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Full</span>
            </button>
          </div>

          {/* Zoom controls for mobile frames */}
          {device !== 'responsive' && (
            <div className="hidden xl:flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-lg p-0.5 text-xs text-slate-400">
              <button
                onClick={() => setScale((s) => Math.max(0.65, Number((s - 0.05).toFixed(2))))}
                className="p-1 hover:text-white rounded"
                title="Zoom Out"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <span className="px-1.5 font-mono text-[11px] min-w-8 text-center">
                {Math.round(scale * 100)}%
              </span>
              <button
                onClick={() => setScale((s) => Math.min(1.2, Number((s + 0.05).toFixed(2))))}
                className="p-1 hover:text-white rounded"
                title="Zoom In"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Reload Preview Button */}
          <button
            onClick={handleRefresh}
            title="প্রিভিউ রিলোড করুন"
            className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          {/* Guide / Info Toggle */}
          <button
            onClick={() => setShowGuide(!showGuide)}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-all ${
              showGuide
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
            }`}
          >
            <Info className="w-3.5 h-3.5" />
            <span className="hidden md:inline">ফিচার গাইড</span>
          </button>

          {/* Open Raw HTML file in new tab */}
          <a
            href="/assets/aistudio/hishab_khata_wrong_password_photo_cc36a4cb.html"
            target="_blank"
            rel="noopener noreferrer"
            title="সরাসরি ব্রাউজারে অ্যাপটি খুলুন"
            className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 transition-colors hidden sm:flex"
          >
            <ExternalLink className="w-4 h-4" />
          </a>
        </div>
      </header>

      {/* Main Preview Area */}
      <div className="flex-1 overflow-auto flex items-center justify-center p-2 sm:p-4 bg-slate-950 relative">
        {/* Subtle grid background */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b08_1px,transparent_1px),linear-gradient(to_bottom,#1e293b08_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none" />

        {/* Device Container */}
        {device === 'responsive' ? (
          <div className="w-full h-full max-w-4xl bg-slate-900 rounded-xl overflow-hidden border border-slate-800 shadow-2xl flex flex-col">
            <iframe
              key={iframeKey}
              ref={iframeRef}
              src="/assets/aistudio/hishab_khata_wrong_password_photo_cc36a4cb.html"
              title="Developed By Affan Live Preview"
              className="w-full h-full border-0 bg-[#f1efe8]"
              sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-modals allow-downloads"
            />
          </div>
        ) : (
          <div
            style={{
              transform: `scale(${scale})`,
              transformOrigin: 'center center',
              transition: 'transform 0.15s ease',
            }}
            className="my-auto"
          >
            {/* Phone Bezel */}
            <div
              style={{
                width: dims.width,
                height: dims.height,
              }}
              className="relative bg-slate-950 rounded-[48px] p-2.5 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9),0_0_0_1px_rgba(255,255,255,0.08),0_0_0_8px_#0f172a] flex flex-col overflow-hidden"
            >
              {/* Dynamic Island / Notch */}
              <div className="absolute top-3.5 left-1/2 -translate-x-1/2 z-20 pointer-events-none flex items-center justify-center">
                {device === 'iphone' ? (
                  <div className="w-24 h-5 bg-black rounded-full flex items-center justify-between px-2.5 shadow-md border border-white/10">
                    <div className="w-2 h-2 rounded-full bg-slate-900 flex items-center justify-center">
                      <div className="w-1 h-1 rounded-full bg-blue-500/40" />
                    </div>
                    <div className="w-1.5 h-1.5 rounded-full bg-slate-800/80" />
                  </div>
                ) : (
                  <div className="w-3.5 h-3.5 rounded-full bg-black border border-slate-800 shadow-sm flex items-center justify-center">
                    <div className="w-1.5 h-1.5 rounded-full bg-blue-500/30" />
                  </div>
                )}
              </div>

              {/* Status Bar */}
              <div className="h-8 px-6 pt-1 flex items-center justify-between text-xs font-semibold text-slate-800 dark:text-slate-200 z-10 pointer-events-none select-none bg-[#f1efe8]">
                <span className="text-[12px] tracking-tight font-medium text-slate-700">{currentTime || '12:00'}</span>
                <div className="flex items-center gap-1.5 text-xs text-slate-700">
                  <span className="text-[10px] tracking-wider font-mono">5G</span>
                  {/* Signal bars */}
                  <div className="flex items-end gap-0.5 h-2.5">
                    <span className="w-0.5 h-1 bg-current rounded-full" />
                    <span className="w-0.5 h-1.5 bg-current rounded-full" />
                    <span className="w-0.5 h-2 bg-current rounded-full" />
                    <span className="w-0.5 h-2.5 bg-current rounded-full" />
                  </div>
                  {/* Battery */}
                  <div className="w-5 h-2.5 border border-current rounded-sm p-0.5 flex items-center">
                    <div className="w-3 h-full bg-current rounded-xs" />
                  </div>
                </div>
              </div>

              {/* Screen Content (The actual app) */}
              <div className="flex-1 bg-[#f1efe8] rounded-b-[36px] overflow-hidden relative flex flex-col">
                <iframe
                  key={iframeKey}
                  ref={iframeRef}
                  src="/assets/aistudio/hishab_khata_wrong_password_photo_cc36a4cb.html"
                  title="Developed By Affan Mobile App"
                  className="w-full h-full border-0 block"
                  sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-modals allow-downloads"
                />
              </div>

              {/* Home Indicator Bar */}
              <div className="h-3.5 flex items-center justify-center pointer-events-none bg-[#f1efe8] rounded-b-[40px]">
                <div className="w-28 h-1 bg-slate-400/60 rounded-full" />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Phone Setup Guide Modal */}
      {showPhoneSetup && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700/80 rounded-2xl max-w-2xl w-full p-5 sm:p-7 shadow-2xl max-h-[92vh] flex flex-col my-auto">
            {/* Header */}
            <div className="flex items-start justify-between pb-4 border-b border-slate-800 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-emerald-500/20 border border-emerald-500/40 p-1 flex items-center justify-center">
                  <img src={dogLogo} alt="App Icon" className="w-full h-full object-contain rounded-lg" />
                </div>
                <div>
                  <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">
                    আপনার ফোনে অ্যাপটি সেটআপ করার নিয়ম
                  </h2>
                  <p className="text-xs text-slate-400">
                    কোনো Play Store বা App Store ছাড়াই ২ মিনিটে আপনার ফোনের হোমস্ক্রিনে ইনস্টল করুন
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowPhoneSetup(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                title="বন্ধ করুন"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick URL Box & QR Code */}
            <div className="bg-slate-950/80 rounded-xl p-3.5 border border-slate-800 mt-4 flex flex-col sm:flex-row items-center gap-4">
              <div className="w-28 h-28 bg-white p-2 rounded-xl shadow shrink-0 flex items-center justify-center">
                <img
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(APP_URL)}`}
                  alt="QR Code"
                  className="w-full h-full object-contain"
                />
              </div>

              <div className="flex-1 w-full space-y-2">
                <div className="text-xs font-semibold text-emerald-400 flex items-center gap-1.5">
                  <QrCode className="w-4 h-4" />
                  <span>ফোনের ক্যামেরা দিয়ে সরাসরি স্ক্যান করুন অথবা লিংক কপি করুন:</span>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={APP_URL}
                    className="flex-1 bg-slate-900 border border-slate-700 text-slate-300 text-xs px-3 py-2 rounded-lg font-mono truncate"
                  />
                  <button
                    onClick={copyAppUrl}
                    className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 shrink-0 transition-colors"
                  >
                    {copiedUrl ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedUrl ? 'কপি হয়েছে' : 'লিংক কপি'}</span>
                  </button>
                </div>
                <p className="text-[11px] text-slate-400">
                  ডিফল্ট পাসওয়ার্ড: <span className="font-mono text-amber-300 font-bold">1234</span>
                </p>
              </div>
            </div>

            {/* OS Selector Tabs */}
            <div className="flex items-center gap-2 mt-4 shrink-0">
              <button
                onClick={() => setPhoneOsTab('android')}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  phoneOsTab === 'android'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'bg-slate-800/80 text-slate-400 hover:text-white'
                }`}
              >
                <span>অ্যান্ড্রয়েড (Android)</span>
              </button>
              <button
                onClick={() => setPhoneOsTab('iphone')}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  phoneOsTab === 'iphone'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'bg-slate-800/80 text-slate-400 hover:text-white'
                }`}
              >
                <span>আইফোন (iPhone / iOS)</span>
              </button>
              <button
                onClick={() => setPhoneOsTab('apk')}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  phoneOsTab === 'apk'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'bg-slate-800/80 text-slate-400 hover:text-white'
                }`}
              >
                <span>APK ফাইল / অফলাইন ডাউনলোড</span>
              </button>
            </div>

            {/* Tab Instructions Content */}
            <div className="mt-4 overflow-y-auto flex-1 pr-1 space-y-3 text-xs text-slate-300">
              {phoneOsTab === 'android' && (
                <div className="space-y-3">
                  <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center shrink-0 text-xs">
                      ১
                    </span>
                    <div>
                      <h4 className="font-semibold text-white">ফোনের Google Chrome ব্রাউজারে লিংকটি খুলুন</h4>
                      <p className="text-slate-400 text-[11px] mt-0.5">
                        আপনার অ্যান্ড্রয়েড ফোনের Chrome ব্রাউজারে উপরের কপি করা লিংকটি পেস্ট করে এন্টার দিন বা কিউআর কোড স্ক্যান করুন।
                      </p>
                    </div>
                  </div>

                  <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center shrink-0 text-xs">
                      ২
                    </span>
                    <div>
                      <h4 className="font-semibold text-white">ডানপাশের ৩-ডট মেন্যুতে (⋮) ট্যাপ করুন</h4>
                      <p className="text-slate-400 text-[11px] mt-0.5">
                        ক্রোম ব্রাউজারের উপরে ডান কোণায় থাকা ৩টি ডট মেন্যু আইকন চাপুন।
                      </p>
                    </div>
                  </div>

                  <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center shrink-0 text-xs">
                      ৩
                    </span>
                    <div>
                      <h4 className="font-semibold text-white">"Install app" অথবা "Add to Home screen" নির্বাচন করুন</h4>
                      <p className="text-slate-400 text-[11px] mt-0.5">
                        মেন্যু থেকে <strong>"Install app" (অ্যাপ ইনস্টল করুন)</strong> চাপুন। এটি স্বয়ংক্রিয়ভাবে আপনার পছন্দের ডগ আইকন এবং <strong className="text-white">"Affan"</strong> নামে ইনস্টল কনফার্মেশন চাইবে।
                      </p>
                    </div>
                  </div>

                  <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center shrink-0 text-xs">
                      ৪
                    </span>
                    <div>
                      <h4 className="font-semibold text-white">হোমস্ক্রিন থেকে এক ক্লিকে ওপেন করুন</h4>
                      <p className="text-slate-400 text-[11px] mt-0.5">
                        এখন আপনার ফোনের হোমস্ক্রিনে অ্যাপ আইকন চলে আসবে। ব্রাউজার ছাড়াই সরাসরি ফুলস্ক্রিনে আসল মোবাইল অ্যাপের মতো চলবে!
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {phoneOsTab === 'iphone' && (
                <div className="space-y-3">
                  <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center shrink-0 text-xs">
                      ১
                    </span>
                    <div>
                      <h4 className="font-semibold text-white">আইফোনের Safari ব্রাউজারে লিংকটি খুলুন</h4>
                      <p className="text-slate-400 text-[11px] mt-0.5">
                        আইফোনে Safari ওপেন করে উপরের লিংকটিতে যান।
                      </p>
                    </div>
                  </div>

                  <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center shrink-0 text-xs">
                      ২
                    </span>
                    <div>
                      <h4 className="font-semibold text-white">নিচের 'Share' (শেয়ার) আইকনে চাপুন</h4>
                      <p className="text-slate-400 text-[11px] mt-0.5">
                        সাফারির স্ক্রিনের নিচে থাকা মাঝখানের শেয়ার আইকনটি (একটি বাক্স যার থেকে তীর চিহ্ন উপরে নির্দেশ করে) ট্যাপ করুন।
                      </p>
                    </div>
                  </div>

                  <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 flex items-start gap-3">
                    <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center shrink-0 text-xs">
                      ৩
                    </span>
                    <div>
                      <h4 className="font-semibold text-white">'Add to Home Screen' চাপুন এবং 'Add' বাটনে ক্লিক করুন</h4>
                      <p className="text-slate-400 text-[11px] mt-0.5">
                        তালিকাটি সামান্য স্ক্রল করে <strong>"Add to Home Screen"</strong> চাপুন। উপরে ডান কোণায় "Add" ট্যাপ করলেই হোমস্ক্রিনে ডগ আইকনসহ অ্যাপটি যুক্ত হবে।
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {phoneOsTab === 'apk' && (
                <div className="space-y-3">
                  <div className="bg-emerald-950/40 border border-emerald-500/50 rounded-xl p-4 shadow-lg">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                          <Smartphone className="w-4 h-4" />
                        </div>
                        <div>
                          <h4 className="font-bold text-white text-sm">Developed_By_Affan.apk প্রস্তুত!</h4>
                          <span className="text-[11px] text-emerald-400 font-medium">আসল অ্যান্ড্রয়েড ইনস্টলার প্যাকেজ (194 KB)</span>
                        </div>
                      </div>
                      <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/30">
                        Signed & Verified
                      </span>
                    </div>

                    <p className="text-slate-300 text-xs leading-relaxed mb-3">
                      আপনার অনুরোধে অ্যাপটিকে সরাসরি অ্যান্ড্রয়েড <strong className="text-white">.apk</strong> ফাইলে রূপান্তর করে দেওয়া হয়েছে। এটি সরাসরি আপনার ফোনে যেকোনো সাধারণ অ্যাপের মতো ইনস্টল হয়ে যাবে।
                    </p>

                    <a
                      href="/Developed_By_Affan.apk"
                      download="Developed_By_Affan.apk"
                      className="inline-flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs shadow-md transition-all hover:scale-102 active:scale-98"
                    >
                      <Download className="w-4 h-4" />
                      <span>Developed_By_Affan.apk ডাউনলোড করুন (194 KB)</span>
                    </a>
                  </div>

                  <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 space-y-2 text-xs">
                    <h5 className="font-semibold text-white flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      <span>ফোনে ইনস্টল করার ৩টি সহজ ধাপ:</span>
                    </h5>
                    <ol className="list-decimal list-inside space-y-1.5 text-slate-300 text-[11px] pl-1">
                      <li>উপরের সবুজ বাটনে চাপ দিয়ে <strong>Developed_By_Affan.apk</strong> ফাইলটি ডাউনলোড করুন।</li>
                      <li>ফাইলটি ক্যাবল বা হোয়াটসঅ্যাপ দিয়ে আপনার ফোনে নিয়ে ট্যাপ করুন।</li>
                      <li>ফোনে <strong>"Install"</strong> চাপুন (যদি "Unknown sources" পারমিশন চায় তবে 'Allow' দিন)।</li>
                      <li>ব্যস! কোনো ব্রাউজার ছাড়া আপনার ফোনের অ্যাপ মেন্যুতে ডগ আইকনসহ অ্যাপ ইনস্টল হয়ে যাবে!</li>
                    </ol>
                  </div>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="mt-4 pt-3 border-t border-slate-800 flex justify-between items-center text-xs text-slate-400 shrink-0">
              <span>পাসওয়ার্ড: <strong className="text-amber-300 font-mono">1234</strong></span>
              <button
                onClick={() => setShowPhoneSetup(false)}
                className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-medium rounded-lg transition-colors"
              >
                বুঝেছি, ধন্যবাদ
              </button>
            </div>
          </div>
        </div>
      )}

      {/* App Logo Showcase Modal */}
      {showLogoModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700/80 rounded-2xl max-w-4xl w-full p-5 sm:p-7 shadow-2xl max-h-[92vh] flex flex-col my-auto">
            {/* Header */}
            <div className="flex items-start justify-between pb-4 border-b border-slate-800 shrink-0">
              <div>
                <div className="flex items-center gap-2">
                  <span className="p-1.5 bg-amber-500/20 text-amber-400 rounded-lg">
                    <Palette className="w-5 h-5" />
                  </span>
                  <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">
                    অ্যাপ আইকন কালেকশন (অফিসিয়াল ডগ আইকন সক্রিয়)
                  </h2>
                </div>
                <p className="text-xs sm:text-sm text-slate-400 mt-1">
                  আপনার পছন্দের স্মাইলিং ডগ লোগোটি শুধুমাত্র অ্যাপ আইকন হিসেবে সেট করা হয়েছে।
                </p>
              </div>

              <button
                onClick={() => setShowLogoModal(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                title="বন্ধ করুন"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Sub-tabs: Gallery vs Home Screen Simulation */}
            <div className="flex items-center gap-2 mt-4 shrink-0">
              <button
                onClick={() => setLogoTab('gallery')}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  logoTab === 'gallery'
                    ? 'bg-amber-600 text-white shadow-sm'
                    : 'bg-slate-800/80 text-slate-400 hover:text-white'
                }`}
              >
                <Grid className="w-3.5 h-3.5" />
                <span>আইকন বিবরণ ও গ্যালারি</span>
              </button>
              <button
                onClick={() => setLogoTab('homescreen')}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  logoTab === 'homescreen'
                    ? 'bg-amber-600 text-white shadow-sm'
                    : 'bg-slate-800/80 text-slate-400 hover:text-white'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>মোবাইল হোমস্ক্রিন প্রিভিউ (Phone Icon Mockup)</span>
              </button>
            </div>

            {/* Modal Body */}
            <div className="mt-4 overflow-y-auto flex-1 pr-1 space-y-4">
              {logoTab === 'gallery' ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {LOGO_OPTIONS.map((logo) => {
                    const isSelected = activeLogo.id === logo.id;
                    return (
                      <div
                        key={logo.id}
                        onClick={() => setActiveLogo(logo)}
                        className={`group relative rounded-xl border p-4 transition-all cursor-pointer flex flex-col justify-between ${
                          isSelected
                            ? 'bg-slate-800/90 border-amber-500 ring-2 ring-amber-500/30 shadow-lg'
                            : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 hover:bg-slate-800/40'
                        }`}
                      >
                        {/* Selected Tag / Badge */}
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                            {logo.tag}
                          </span>
                          {isSelected ? (
                            <span className="flex items-center gap-1 text-[11px] font-semibold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20">
                              <CheckCircle2 className="w-3 h-3" /> সক্রিয় আইকন (Active)
                            </span>
                          ) : (
                            <span className="text-[11px] text-slate-500 group-hover:text-slate-300">
                              সিলেক্ট করতে ক্লিক করুন
                            </span>
                          )}
                        </div>

                        {/* Logo Image & App Icon Squircle Preview */}
                        <div className="flex items-center gap-4 mb-3">
                          {/* Full Artwork */}
                          <div className="w-28 h-28 rounded-2xl overflow-hidden shadow-lg border border-slate-700 bg-slate-900/90 shrink-0 group-hover:scale-102 transition-transform flex items-center justify-center p-1">
                            <img
                              src={logo.src}
                              alt={logo.titleBn}
                              className="w-full h-full object-contain"
                            />
                          </div>

                          {/* App Icon (Squircle Mockup) */}
                          <div className="flex flex-col items-center">
                            <div className="w-16 h-16 rounded-[18px] overflow-hidden shadow-md border-2 border-white/20 p-1 bg-amber-950/30 relative flex items-center justify-center">
                              <img
                                src={logo.src}
                                alt={logo.titleBn}
                                className="w-full h-full object-contain rounded-[14px]"
                              />
                            </div>
                            <span className="text-[10px] font-semibold text-amber-300 mt-1">
                              Affan App
                            </span>
                            <span className="text-[9px] text-slate-500 font-mono">
                              (App Icon)
                            </span>
                          </div>
                        </div>

                        {/* Titles & Descriptions */}
                        <div className="space-y-1">
                          <h3 className="font-bold text-white text-sm flex items-center justify-between">
                            <span>{logo.titleBn}</span>
                            <span className="text-xs font-normal text-slate-400 font-mono">
                              {logo.titleEn}
                            </span>
                          </h3>
                          <p className="text-[11px] font-medium text-amber-400">
                            {logo.themeBn}
                          </p>
                          <p className="text-xs text-slate-300 leading-relaxed pt-1">
                            {logo.descriptionBn}
                          </p>
                        </div>

                        {/* Action buttons inside card */}
                        <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setActiveLogo(logo);
                            }}
                            className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                              isSelected
                                ? 'bg-amber-600 text-white'
                                : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                            }`}
                          >
                            {isSelected ? (
                              <>
                                <Check className="w-3.5 h-3.5" />
                                <span>সক্রিয় আইকন</span>
                              </>
                            ) : (
                              <span>আইকন হিসেবে বাছুন</span>
                            )}
                          </button>

                          <a
                            href={logo.src}
                            download={`app_logo_${logo.id}.png`}
                            onClick={(e) => e.stopPropagation()}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
                            title="আইকন ডাউনলোড করুন"
                          >
                            <Download className="w-4 h-4" />
                          </a>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                /* Home Screen Simulation Tab */
                <div className="bg-slate-950 rounded-2xl border border-slate-800 p-6 flex flex-col items-center">
                  <div className="text-center max-w-md mb-6">
                    <h3 className="font-bold text-white text-base">
                      স্মার্টফোন হোমস্ক্রিন মকআপ
                    </h3>
                    <p className="text-xs text-slate-400 mt-1">
                      ব্যবহারকারী যখন ফোনে অ্যাপটি ইনস্টল করবেন, তখন ফোনের হোমস্ক্রিনে আপনার নির্বাচিত ডগ আইকনটি এমন দেখাবে:
                    </p>
                  </div>

                  {/* Phone Screen Mockup */}
                  <div className="w-[320px] h-[520px] rounded-[36px] bg-gradient-to-b from-amber-950/40 via-slate-900 to-slate-950 border-4 border-slate-700 shadow-2xl p-4 flex flex-col justify-between relative overflow-hidden">
                    {/* Wallpaper Glow */}
                    <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

                    {/* Clock & Date Widget */}
                    <div className="text-center pt-6 z-10">
                      <div className="text-3xl font-light text-white font-mono tracking-tight">
                        {currentTime || '12:00'}
                      </div>
                      <div className="text-[11px] text-slate-300 font-medium mt-0.5">
                        শুক্রবার, ১০ নভেম্বর
                      </div>
                    </div>

                    {/* App Icons Grid */}
                    <div className="grid grid-cols-4 gap-4 px-2 z-10">
                      {/* App 1: Developed By Affan (HERO DOGE) */}
                      <div
                        onClick={() => setLogoTab('gallery')}
                        className="flex flex-col items-center cursor-pointer group"
                      >
                        <div className="w-14 h-14 rounded-[18px] overflow-hidden shadow-xl border-2 border-amber-400 p-1 bg-amber-950/60 relative ring-4 ring-amber-500/30 transition-transform group-hover:scale-110 flex items-center justify-center">
                          <img
                            src={activeLogo.src}
                            alt={activeLogo.titleBn}
                            className="w-full h-full object-contain rounded-[14px]"
                          />
                          {/* Notification badge */}
                          <div className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center border border-white">
                            1
                          </div>
                        </div>
                        <span className="text-[11px] font-bold text-amber-300 mt-1.5 tracking-tight text-center truncate max-w-16">
                          Affan
                        </span>
                      </div>

                      {/* Mock Other Apps */}
                      <div className="flex flex-col items-center">
                        <div className="w-14 h-14 rounded-[18px] bg-emerald-600 flex items-center justify-center shadow-lg text-white">
                          <Users className="w-6 h-6" />
                        </div>
                        <span className="text-[10px] text-slate-300 mt-1.5">Contacts</span>
                      </div>

                      <div className="flex flex-col items-center">
                        <div className="w-14 h-14 rounded-[18px] bg-blue-600 flex items-center justify-center shadow-lg text-white">
                          <FileText className="w-6 h-6" />
                        </div>
                        <span className="text-[10px] text-slate-300 mt-1.5">Files</span>
                      </div>

                      <div className="flex flex-col items-center">
                        <div className="w-14 h-14 rounded-[18px] bg-slate-800 flex items-center justify-center shadow-lg text-white border border-slate-700">
                          <Camera className="w-6 h-6 text-slate-300" />
                        </div>
                        <span className="text-[10px] text-slate-300 mt-1.5">Camera</span>
                      </div>
                    </div>

                    {/* Quick Logo Switcher Bar directly inside mockup */}
                    <div className="bg-slate-900/90 backdrop-blur-md rounded-2xl p-2.5 border border-slate-800 z-10">
                      <div className="text-[10px] text-slate-400 font-medium mb-1.5 text-center">
                        আইকন বদলে দেখতে নিচে ট্যাপ করুন:
                      </div>
                      <div className="flex items-center justify-around gap-1.5">
                        {LOGO_OPTIONS.map((logo) => (
                          <button
                            key={logo.id}
                            onClick={() => setActiveLogo(logo)}
                            className={`w-10 h-10 rounded-xl overflow-hidden border-2 transition-transform hover:scale-110 p-0.5 bg-slate-950 flex items-center justify-center ${
                              activeLogo.id === logo.id
                                ? 'border-amber-400 ring-2 ring-amber-400/40 scale-105'
                                : 'border-slate-700 opacity-70 hover:opacity-100'
                            }`}
                            title={logo.titleBn}
                          >
                            <img src={logo.src} alt={logo.titleBn} className="w-full h-full object-contain" />
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Dock */}
                    <div className="h-16 bg-white/10 backdrop-blur-xl rounded-[24px] px-4 flex items-center justify-around z-10 border border-white/10">
                      <div className="w-10 h-10 rounded-full bg-amber-500 flex items-center justify-center text-white shadow-md">
                        <Smartphone className="w-5 h-5" />
                      </div>
                      <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white shadow-md">
                        <Camera className="w-5 h-5" />
                      </div>
                      <div className="w-10 h-10 rounded-full bg-emerald-500 flex items-center justify-center text-white shadow-md">
                        <ShieldCheck className="w-5 h-5" />
                      </div>
                      <div className="w-10 h-10 rounded-full bg-indigo-500 flex items-center justify-center text-white shadow-md">
                        <Fingerprint className="w-5 h-5" />
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="mt-4 pt-3 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <span>বর্তমান নির্বাচিত আইকন:</span>
                <strong className="text-amber-400 font-medium">
                  {activeLogo.titleBn}
                </strong>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <button
                  onClick={() => setShowLogoModal(false)}
                  className="flex-1 sm:flex-none px-5 py-2 bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs rounded-lg transition-colors shadow-md"
                >
                  ✓ এটি নিশ্চিত করুন (Confirm)
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Feature Guide Modal */}
      {showGuide && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-xl w-full p-6 shadow-2xl overflow-y-auto max-h-[90vh]">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-400" />
                <h2 className="text-base font-semibold text-white">
                  Developed By Affan অ্যাপের ফিচার গাইড
                </h2>
              </div>
              <button
                onClick={() => setShowGuide(false)}
                className="text-slate-400 hover:text-white text-xs px-2.5 py-1 rounded-md bg-slate-800"
              >
                ✕ বন্ধ করুন
              </button>
            </div>

            <div className="mt-4 space-y-3.5 text-xs text-slate-300 leading-relaxed">
              <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3.5">
                <div className="flex items-center gap-2 text-emerald-400 font-medium text-sm mb-1">
                  <ShieldCheck className="w-4 h-4" />
                  <span>১. ফিক্সড হেডার ও সেন্টার্ড আনলক স্ক্রিন (PIN: 1234)</span>
                </div>
                <p className="text-slate-400">
                  স্ক্রল করলেও ওপরের হেডারটি আর সরে যাবে না। ফিঙ্গারপ্রিন্ট বাটন ও পাসওয়ার্ড বক্স সম্পূর্ণ স্ক্রিনের ঠিক মাঝখানে সাজানো হয়েছে।
                </p>
              </div>

              <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3.5">
                <div className="flex items-center gap-2 text-rose-400 font-medium text-sm mb-1">
                  <Camera className="w-4 h-4" />
                  <span>২. ৩ বার ভুল পাসওয়ার্ডে ইনট্রুডার ছবি</span>
                </div>
                <p className="text-slate-400">
                  ভুল পাসওয়ার্ড দিয়ে আনলক করার চেষ্টা করলে ৩য় বারের পর ৬০ সেকেন্ডের জন্য লকআউট হবে এবং ক্যামেরা ছবি তুলে সেটিংসের তালিকাটিতে যুক্ত করবে।
                </p>
              </div>

              <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3.5">
                <div className="flex items-center gap-2 text-blue-400 font-medium text-sm mb-1">
                  <Users className="w-4 h-4" />
                  <span>৩. Shorika কর্মী ডিরেক্টরি & QID অ্যালার্ট</span>
                </div>
                <p className="text-slate-400">
                  ১১০+ জন প্রবাসী কর্মীর কাতার আইডি, মেয়াদ, দেশ ও ফোন নম্বর। নম্বরে চেপে ধরে রাখলে ফোনের ডায়ালার খুলে যাবে।
                </p>
              </div>

              <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3.5">
                <div className="flex items-center gap-2 text-amber-400 font-medium text-sm mb-1">
                  <FileText className="w-4 h-4" />
                  <span>৪. হিসাব খাতা & বাকি ট্র্যাকার + PDF</span>
                </div>
                <p className="text-slate-400">
                  প্রতি মাসের ক্যাশ-বুক হিসাব, আগের মাসের উদ্বৃত্ত, মাস শেষের ব্যালেন্স এবং PDF স্টেটমেন্ট ডাউনলোড করার সুবিধা।
                </p>
              </div>
            </div>

            <div className="mt-5 pt-3 border-t border-slate-800 flex justify-between items-center text-xs text-slate-400">
              <span>ডিফল্ট পিন: <strong className="text-amber-300 font-mono">1234</strong></span>
              <button
                onClick={() => setShowGuide(false)}
                className="px-4 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-medium rounded-lg transition-colors"
              >
                বুঝেছি
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footer Info Strip */}
      <footer className="h-8 border-t border-slate-800/80 bg-slate-950 text-[11px] text-slate-400 px-4 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
            <strong className="text-slate-200">Developed By Affan</strong> প্রস্তুত
          </span>
          <span className="hidden sm:inline text-slate-600">|</span>
          <span className="hidden sm:inline">পাসওয়ার্ড: <strong className="text-slate-200 font-mono">1234</strong></span>
          <span className="hidden md:inline text-slate-600">|</span>
          <span className="hidden md:inline text-amber-400">লোগো আইকন: {activeLogo.titleBn}</span>
        </div>
        <div className="flex items-center gap-3 text-slate-500">
          <span>Developed By Affan v2.4</span>
        </div>
      </footer>
    </div>
  );
}
